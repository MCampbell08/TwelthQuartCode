﻿using System;

namespace Lab04_NonDeterAndFiniteStateMachine
{
    class Program
    {
        static void Main(string[] args)
        {
            ConsoleManager manager = new ConsoleManager();

            manager.Run();
        }
    }
}
