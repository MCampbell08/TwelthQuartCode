﻿using System;

namespace Lab02_FiniteStateMachine
{
    public class Program
    {
        public static void Main(string[] args)
        {
            ConsoleManager manager = new ConsoleManager();
            manager.Run();
        }
    }
}
