﻿using System;

namespace Lab05_ContextFreeLanguage
{
    public class Program
    {
        public static void Main(string[] args)
        {
            ConsoleManager manager = new ConsoleManager();

            manager.Run();
        }
    }
}
