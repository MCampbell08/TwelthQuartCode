﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AnsweringQuestions.Models
{
    public class Route
    {
        public string StartingPos { get; set; }
        public string EndingPos { get; set; }
        public string Distance { get; set; }
    }
}
