﻿using System;

namespace AnsweringQuestions
{
    public class Program
    {
        public static void Main(string[] args)
        {
            TourGuide guide = new TourGuide();

            guide.StartTour();
        }
    }
}
