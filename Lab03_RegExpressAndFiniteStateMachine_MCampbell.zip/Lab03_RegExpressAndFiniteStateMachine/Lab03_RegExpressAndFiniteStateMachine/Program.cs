﻿using System;

namespace Lab03_RegExpressAndFiniteStateMachine
{
    class Program
    {
        static void Main(string[] args)
        {
            ConsoleManager manager = new ConsoleManager();

            manager.Run();
        }
    }
}
